import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['b','g','r','c','m','y','k','w']
markers = ['o','x','1','2','3','4']

font = {'weight': 'normal',
        'size': 24,}

rc('axes', linewidth=2)

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 20, mfc='none')

	plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 24, 'weight':'normal'})
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=26)
	plt.tick_params(axis='both', which='minor', labelsize=26)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines, strt_line, end_line, cmine_pos, delition_pos):
    cmine = []
    delition = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        cmine.append(float(line[cmine_pos])/100.0)
        delition.append(float(line[delition_pos])/100.0)
    
    return cmine, delition

def get_CND_values(lines, strt_line, end_line, cmine_pos, delition_pos):
    cmine = []
    delition = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        cmine.append(float(line[cmine_pos])/1000.0)
        delition.append(float(line[delition_pos])/1000.0)
    
    return cmine, delition

def plot_ET():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_ET_values(lines, 1, 5, 6, 5)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(5,26,5)
    
    x_dummy_plt = np.arange(0, 26, 5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%5==0):
            x_ticks.append(str(i))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 100, 20)
    title = "synthetic changing increment delition"
    x_label = r'$ \Delta^- $'+ "("+r'$ \times 10^3$'+") (" +r'$ \Delta^+ $' + "= 10K)"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_delition_constant_increment.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 26], [0, 75], filename, 2)


def plot_CND():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_CND_values(lines, 1, 5, 8, 7)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(5,26,5)
    
    x_dummy_plt = np.arange(0, 26, 5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%5==0):
            x_ticks.append(str(i))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 101, 20)
    title = "synthetic changing increment delition"
    x_label = r'$ \Delta^- $'+ "("+r'$ \times 10^3$'+") (" +r'$ \Delta^+ $' + "= 10K)"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_delition_constant_increment_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 26], [0, 101], filename, 2)

if (__name__=='__main__'):
    plot_ET()
    plot_CND()