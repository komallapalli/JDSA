import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['b','g','r','c','m','y','k','w']
markers = ['o','x','1','2','3','4']

font = {'weight': 'normal',
        'size': 24,}

rc('axes', linewidth=2)

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 20, mfc='none')

	plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 24, 'weight':'normal'})
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=26)
	plt.tick_params(axis='both', which='minor', labelsize=26)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines_cmine, lines_increment, strt_line, end_line, cmine_pos, increment_pos):
    cmine = []
    increment = []
    for i in range(strt_line, end_line+1, 1):
        line1 = lines_cmine[i].split(",")
        line2 = lines_increment[i].split(",")

        cmine.append(float(line1[cmine_pos])/100.0)
        increment.append(float(line2[increment_pos])/100.0)

    return cmine, increment

def get_CND_values(lines_cmine, lines_increment, strt_line, end_line, cmine_pos, increment_pos):
    cmine = []
    increment = []
    for i in range(strt_line, end_line+1, 1):
        line1 = lines_cmine[i].split(",")
        line2 = lines_increment[i].split(",")

        cmine.append(float(line1[cmine_pos])/1000.0)
        increment.append(float(line2[increment_pos])/1000.0)

    return cmine, increment

def plot_ET_Inc():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("time_increment_synthetic.csv",'r').readlines()
    cmine, increment = get_ET_values(lines_cmine, lines_increment, 1, 10, 8, 9)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(5,51,5)

    x_dummy_plt = np.arange(0, 51, 5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 10, 2)
    title = "synthetic changing increment"
    x_label = r'$ \Delta^+ $'+" ("+r'$ \times 10^3$'+")"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CMine','GCPM')
    filename = "images/synthetic_increment.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [0, 7], filename, 2)

def plot_ET_maxOR():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("time_increment_synthetic.csv",'r').readlines()
    cmine, increment = get_ET_values(lines_cmine, lines_increment, 12, 17, 8, 9)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(5, 31, 5)

    x_dummy_plt = np.arange(0, 31, 5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i/100.0))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 21, 5)
    title = "synthetic changing maxOR"
    x_label = "maxOR"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CPM','GCPM')
    filename = "images/synthetic_maxOR.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 31], [0, 17], filename, 2)



def plot_ET_minRF():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("time_increment_synthetic.csv",'r').readlines()
    cmine, increment = get_ET_values(lines_cmine, lines_increment, 19, 24, 8, 9)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(450,576,25)

    x_dummy_plt = np.arange(450, 576, 25)
    x_ticks = []
    for i in x_dummy_plt:
        x_ticks.append(str(i))
        # if(i%50==0):
        #     x_ticks.append(str(i))
        # else:
        #     x_ticks.append("")
    y_ticks = np.arange(0, 5, 1)
    title = "synthetic changing minRF"
    x_label = "minRF ("+r'$ \times 10^{-4}$'+")"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CPM','GCPM')
    filename = "images/synthetic_minRF.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [450, 576], [0, 3.5], filename, 1)


def plot_CND_Inc():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("time_increment_synthetic.csv",'r').readlines()
    cmine, increment = get_CND_values(lines_cmine, lines_increment, 1, 10, 7, 7)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(5,51,5)

    x_dummy_plt = np.arange(0, 51, 5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 21, 4)
    title = "synthetic changing increment"
    x_label = r'$ \Delta^+ $'+" ("+r'$ \times 10^3$'+")"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CMine','GCPM')
    filename = "images/synthetic_increment_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [0, 14], filename, 2)

def plot_CND_maxOR():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("time_increment_synthetic.csv",'r').readlines()
    cmine, increment = get_CND_values(lines_cmine, lines_increment, 12, 17, 7, 7)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(5,31,5)

    x_dummy_plt = np.arange(0, 31, 5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i/100.0))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 21, 5)
    title = "synthetic changing maxOR"
    x_label = "maxOR"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CPM','GCPM')
    filename = "images/synthetic_maxOR_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 31], [0, 17], filename, 2)

def plot_CND_minRF():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("time_increment_synthetic.csv",'r').readlines()
    cmine, increment = get_CND_values(lines_cmine, lines_increment, 19, 24, 7, 7)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(450,576,25)

    x_dummy_plt = np.arange(450, 576, 25)
    x_ticks = []
    for i in x_dummy_plt:
        x_ticks.append(str(i))
        # if(i%50==0):
        #     x_ticks.append(str(i))
        # else:
        #     x_ticks.append("")
    y_ticks = np.arange(0, 11, 2)
    title = "synthetic changing minRF"
    x_label = "minRF ("+r'$ \times 10^{-4}$'+")"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CPM','GCPM')
    filename = "images/synthetic_minRF_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [450, 576], [0, 7], filename, 1)


if (__name__=='__main__'):
    # plot_ET_Inc()
    # plot_ET_maxOR()
    plot_ET_minRF()
    # plot_CND_Inc()
    # plot_CND_maxOR()
    plot_CND_minRF()
