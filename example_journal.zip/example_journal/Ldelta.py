import itertools
import sys
import ast
# from bitarray import bitarray
import time
import operator

def NOP_generation(cand,DB,max_or):

    Q = cand
    diq = {}
    adiq = {}
    for i in Q:
        diq['.'.join(i)] = [0,0]
        adiq['.'.join(i)] = [0,0]
    f = open(DB,'r')
    for line in f:
        line = line.strip('\n')
        items = line.split(',')
        for j in Q:
            flagq = 0
            for k in j[:-1]:
                if k in items:
                    flagq = 1
                    break
            if j[-1] in items:
                diq['.'.join(j)][1] += 1
                if flagq == 1:
                    diq['.'.join(j)][0] += 1

    # fa = open(Add,'r')
    # for line in fa:
    #     line = line.strip('\n')
    #     aitems = line.split(',')
    #     for j in Q:
    #         aflagq = 0
    #         for k in j[:-1]:
    #             if k in aitems:
    #                 aflagq = 1
    #                 break
    #         if j[-1] in aitems:
    #             adiq['.'.join(j)][1] += 1
    #             if aflagq == 1:
    #                 adiq['.'.join(j)][0] += 1
    print(diq)
    # print(adiq)

    return Q



if __name__ == '__main__':
    DB = sys.argv[1]
    min_rf = sys.argv[2]
    min_rf = float(min_rf)
    max_or = sys.argv[3]
    max_or = float(max_or)

    # cand = [['b', 'd'], ['b', 'a'], ['b', 'c'], ['b', 'e'], ['d', 'a'], ['d', 'c'], ['d', 'e'], ['a', 'c'], ['a', 'e'], ['c', 'e']]
    # nop = [['b', 'a'], ['b', 'c'], ['b', 'e'], ['a', 'd'], ['a', 'e'], ['c', 'd'], ['c', 'e'], ['d', 'e']]
    r_k = [['d', 'a'], ['d', 'c'], ['a', 'c']]
    # temp = [['b', 'd'], ['a', 'c']]
    NOP_generation(r_k,DB,max_or)
