import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['b','g','r','c','m','y','k','w']
markers = ['o','x','1','2','3','4']

font = {'weight': 'normal',
        'size': 24,}

rc('axes', linewidth=2)

# def plot_graph(x_1,x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
#     plt.plot(x, y[0], color[0], marker=markers[0],markersize = 20, mfc='none')
#     plt.plot(x_1, y[1], color[1], marker=markers[1],markersize = 20, mfc='none')
#
#     plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 24, 'weight':'normal'})
#     plt.xticks(xx,xticks)
#     plt.yticks(yticks)
#     plt.tick_params(axis='both', which='major', labelsize=26)
#     plt.tick_params(axis='both', which='minor', labelsize=26)
#
#     axes = plt.gca()
#     axes.set_xlim(xlim)
#     axes.set_ylim(ylim)
#     axes.set_xlabel(x_label, fontdict = font)
#     axes.set_ylabel(y_label, fontdict = font)
#
#     plt.tight_layout()
#     plt.savefig(filename, format='eps', dpi=1000)
#     plt.show()
#
# def get_ET_values(lines, strt_line, end_line, cmine_pos):
#     cmine = []
#     for i in range(strt_line, end_line+1, 1):
#         line = lines[i].split(",")
#
#         cmine.append(float(line[cmine_pos])/100.0)
#
#     return cmine
#
# def get_CND_values(lines, strt_line, end_line, cmine_pos):
#     cmine = []
#     for i in range(strt_line, end_line+1, 1):
#         line = lines[i].split(",")
#
#         cmine.append(float(line[cmine_pos])/1000.0)
#
#     return cmine

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 20, mfc='none')

	plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 24, 'weight':'normal'})
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=26)
	plt.tick_params(axis='both', which='minor', labelsize=26)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines, strt_line, end_line, cmine_pos, delition_pos):
    cmine = []
    delition = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        cmine.append(float(line[cmine_pos])/100.0)
        delition.append(float(line[delition_pos])/100.0)

    return cmine, delition

def plot_ET_Inc():
    lines = open("synthetic.csv",'r').readlines()
    cmine = get_ET_values(lines, 1, 6, 5)
    delition = get_ET_values(lines, 2, 6, 4)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(0,51,10)
    x_1 = np.arange(10,51,10)

    x_dummy_plt = np.arange(0,51, 10)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 121, 20)
    title = "Synthetic changing delition"
    x_label = r'$ \Delta^- $'+" ("+r'$ \times 10^3$'+")"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_delition.eps"
    plot_graph(x_1,x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [20, 120], filename, 2)

def plot_ET_maxOR():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_ET_values(lines, 7, 10, 5, 4)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(10,41,10)

    x_dummy_plt = np.arange(0, 41, 10)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i/100.0))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 106, 5)
    title = "synthetic changing maxOR"
    x_label = "maxOR"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_maxOR.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 41], [0, 30], filename, 2)



def plot_ET_minRF():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_ET_values(lines, 13, 18, 5, 4)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(450,576,25)

    x_dummy_plt = np.arange(450, 576, 25)
    x_ticks = []
    for i in x_dummy_plt:
        x_ticks.append(str(i))
        # if(i%5==0 and i%10!=0):
        #     x_ticks.append(str(i))
        # else:
        #     x_ticks.append("")
    y_ticks = np.arange(0, 31, 5)
    title = "synthetic changing minRF"
    x_label = "minRF ("+r'$ \times 10^{-4}$'+")"
    y_label = "ET ("+r'$ \times 10^2$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_minRF.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [450, 576], [0, 31], filename, 1)


def plot_CND_Inc():
    lines = open("synthetic.csv",'r').readlines()
    cmine = get_CND_values(lines, 1, 6, 7)
    delition = get_CND_values(lines, 2, 6, 6)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(0,51,10)
    x_1 = np.arange(10,51,10)

    x_dummy_plt = np.arange(0,51, 10)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 121, 20)
    title = "Synthetic changing delition"
    x_label = r'$ \Delta^- $'+" ("+r'$ \times 10^3$'+")"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_delition_cnd.eps"
    plot_graph(x_1,x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [20, 120], filename, 2)

def plot_CND_maxOR():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_CND_values(lines, 7, 10, 7, 6)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(10,41,10)

    x_dummy_plt = np.arange(0, 41, 10)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%10==0):
            x_ticks.append(str(i/100.0))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 76, 10)
    title = "synthetic changing maxOR"
    x_label = "maxOR"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_maxOR_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 41], [0, 47], filename, 2)

def plot_CND_minRF():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_CND_values(lines, 13, 18, 7, 6)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(450,576,25)

    x_dummy_plt = np.arange(450, 576, 25)
    x_ticks = []
    for i in x_dummy_plt:
        x_ticks.append(str(i))
        # if(i%5==0 and i%10!=0):
        #     x_ticks.append(str(i))
        # else:
        #     x_ticks.append("")
    y_ticks = np.arange(0, 71, 10)
    title = "synthetic changing minRF"
    x_label = "minRF ("+r'$ \times 10^{-4}$'+")"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CMine','UPCMine')
    filename = "images/synthetic_minRF_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [450, 576], [0, 47], filename, 1)


if (__name__=='__main__'):
    # plot_ET_Inc()
    # plot_ET_maxOR()
    plot_ET_minRF()
    # plot_CND_Inc()
    # plot_CND_maxOR()
    plot_CND_minRF()
