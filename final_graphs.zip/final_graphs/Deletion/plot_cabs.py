import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['k','k','k','k','m','y','k','w']
markers = ['o','x','s','^','3','4']


font = {'weight': 'normal',
        'size': 18,}

rc('axes', linewidth=2)

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 12, mfc='none')

	plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 16, 'weight':'normal'},ncol=2)
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=20)
	plt.tick_params(axis='both', which='minor', labelsize=20)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines, strt_line, end_line, cmine_pos, delition_pos):
    cmine = []
    delition = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        cmine.append(float(line[cmine_pos])/100.0)
        delition.append(float(line[delition_pos])/100.0)

    return cmine, delition

# def get_CND_values(lines, strt_line, end_line, cmine_pos, delition_pos):
#     cmine = []
#     delition = []
#     for i in range(strt_line, end_line+1, 1):
#         line = lines[i].split(",")
#
#         cmine.append(float(line[cmine_pos])/1000.0)
#         delition.append(float(line[delition_pos])/1000.0)
#
#     return cmine, delition

def plot_ET_Inc():
    lines = open("DeltaDBtimecabs.csv",'r').readlines()
    cmine, delition = get_ET_values(lines, 1, 10, 5, 4)
    deltime = [1.340130510395, 2.6345759817, 3.929021453005, 5.223466924309999, 7.884170394855, 10.0448738654, 16.2471992507, 24.449524636, 33.1826900216, 41.4158554072]
    DBtime = [1.457326744605, 1.3870544983, 1.3167822519949999, 1.24651000569, 6.807669200145, 12.8688283946, 20.5814080943, 28.293987794, 29.325655033399997, 30.8573222728]


    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    y_plt.append(deltime)
    y_plt.append(DBtime)
    x_plt = np.arange(2,21,2)

    x_dummy_plt = np.arange(2,21, 2)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%4==0):
            x_ticks.append(str(int(i)))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 81, 20)
    title = "cabs120k08 changing delition"
    x_label = r'$ \Delta^- $'+" ("+r'$ \times 10^4$'+")"
    y_label = "ET ("+r'$ \times 10^2$'+") s"
    legends = ('CPM','CCPM','CCPM(d)','CCPM(D)')
    filename = "images/cabs_delition.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 20], [0, 85], filename, 2)

# def plot_ET_maxOR():
#     lines = open("cabs120k08.csv",'r').readlines()
#     cmine, delition = get_ET_values(lines, 12, 21, 5, 4)
#
#     y_plt = []
#     y_plt.append(cmine)
#     y_plt.append(delition)
#     x_plt = np.arange(5,51,5)
#
#     x_dummy_plt = np.arange(5, 51, 5)
#     x_ticks = []
#     for i in x_dummy_plt:
#         if(i%10==0):
#             x_ticks.append(str(i/100.0))
#         else:
#             x_ticks.append("")
#     y_ticks = np.arange(0, 29, 4)
#     title = "cabs120k08 changing maxOR"
#     x_label = "maxOR"
#     y_label = "ET ("+r'$ \times 10^2$'+")"
#     legends = ('CPM','GCPM')
#     filename = "images/cabs_maxOR.eps"
#     plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [0, 25], filename, 2)
#
#
#
# def plot_ET_minRF():
#     lines = open("cabs120k08.csv",'r').readlines()
#     cmine, delition = get_ET_values(lines, 23, 28, 5, 4)
#
#     y_plt = []
#     y_plt.append(cmine)
#     y_plt.append(delition)
#     x_plt = np.arange(35,61,5)
#
#     x_dummy_plt = np.arange(35, 61, 5)
#     x_ticks = []
#     for i in x_dummy_plt:
#         if(i%5==0):
#             x_ticks.append(str(i))
#         else:
#             x_ticks.append("")
#     y_ticks = np.arange(0, 26, 5)
#     title = "cabs120k08 changing minRF"
#     x_label = "minRF ("+r'$ \times 10^{-3}$'+")"
#     y_label = "ET ("+r'$ \times 10^2$'+")"
#     legends = ('CPM','GCPM')
#     filename = "images/cabs_minRF.eps"
#     plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [35, 61], [0, 26], filename, 1)
#
#
# def plot_CND_Inc():
#     lines = open("cabs120k08.csv",'r').readlines()
#     cmine, delition = get_CND_values(lines, 1, 10, 7, 6)
#
#     y_plt = []
#     y_plt.append(cmine)
#     y_plt.append(delition)
#     x_plt = np.arange(2,21,2)
#
#     x_dummy_plt = np.arange(2,21, 2)
#     x_ticks = []
#     for i in x_dummy_plt:
#         if(i%4==0):
#             x_ticks.append(str(int(i)))
#         else:
#             x_ticks.append("")
#     y_ticks = np.arange(0, 71, 10)
#     title = "cabs120k08 changing delition"
#     x_label = r'$ \Delta^- $'+" ("+r'$ \times 10^4$'+")"
#     y_label = "NC ("+r'$ \times 10^3$'+")"
#     legends = ('CPM','GCPM')
#     filename = "images/cabs_delition_cnd.eps"
#     plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 20], [0, 71], filename, 2)
#
# def plot_CND_maxOR():
#     lines = open("cabs120k08.csv",'r').readlines()
#     cmine, delition = get_CND_values(lines, 12, 21, 7, 6)
#
#     y_plt = []
#     y_plt.append(cmine)
#     y_plt.append(delition)
#     x_plt = np.arange(5,51,5)
#
#     x_dummy_plt = np.arange(5, 51, 5)
#     x_ticks = []
#     for i in x_dummy_plt:
#         if(i%10==0):
#             x_ticks.append(str(i/100.0))
#         else:
#             x_ticks.append("")
#     y_ticks = np.arange(0, 29, 4)
#     title = "cabs120k08 changing maxOR"
#     x_label = "maxOR"
#     y_label = "NC ("+r'$ \times 10^3$'+")"
#     legends = ('CPM','GCPM')
#     filename = "images/cabs_maxOR_cnd.eps"
#     plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [0, 25], filename, 2)
#
# def plot_CND_minRF():
#     lines = open("cabs120k08.csv",'r').readlines()
#     cmine, delition = get_CND_values(lines, 23, 28, 7, 6)
#
#     y_plt = []
#     y_plt.append(cmine)
#     y_plt.append(delition)
#     x_plt = np.arange(35,61,5)
#
#     x_dummy_plt = np.arange(35, 61, 5)
#     x_ticks = []
#     for i in x_dummy_plt:
#         if(i%5==0):
#             x_ticks.append(str(i))
#         else:
#             x_ticks.append("")
#     y_ticks = np.arange(0, 26, 5)
#     title = "cabs120k08 changing minRF"
#     x_label = "minRF ("+r'$ \times 10^{-3}$'+")"
#     y_label = "NC ("+r'$ \times 10^3$'+")"
#     legends = ('CPM','GCPM')
#     filename = "images/cabs_minRF_cnd.eps"
#     plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [35, 61], [0, 21], filename, 1)


if (__name__=='__main__'):
    plot_ET_Inc()
    # plot_ET_maxOR()
    # plot_ET_minRF()
    # plot_CND_Inc()
    # plot_CND_maxOR()
    # plot_CND_minRF()
