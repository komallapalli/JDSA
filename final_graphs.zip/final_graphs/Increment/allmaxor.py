import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams
import matplotlib.gridspec as gridspec


color = ['k','k','k','k','k','k','k','w']
markers = ['o','x','s','^','d','*']

font = {'weight': 'normal',
		'size': 18,}

rc('axes', linewidth=2)

# def plot_graph1(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, xlim2, ylim, ylim2, filename, legend_pos):
# 	# y = range(2,20,2)
# 	xlimratio = (xlim[1]-xlim[0])/(xlim2[1]-xlim2[0]+xlim[1]-xlim[0])
# 	xlim2ratio = (xlim2[1]-xlim2[0])/(xlim2[1]-xlim2[0]+xlim[1]-xlim[0])
#
# 	ylimratio = (ylim[1]-ylim[0])/(ylim2[1]-ylim2[0]+ylim[1]-ylim[0])
# 	ylim2ratio = (ylim2[1]-ylim2[0])/(ylim2[1]-ylim2[0]+ylim[1]-ylim[0])
#
# 	gs = gridspec.GridSpec(1, 2, width_ratios=[xlimratio, xlim2ratio])
# 	bs = gridspec.GridSpec(1, 2, width_ratios=[ylimratio, ylim2ratio])
#
# 	fig = plt.figure()
#
# 	ax = fig.add_subplot(gs[0])
# 	ax2 = fig.add_subplot(gs[1])
#
# 	bx = fig.add_subplot(bs[0])
# 	bx2 = fig.add_subplot(bs[1])
#
#
# 	for i in range(len(y)):
# 		bx2.plot(x, y[i], color[i], marker=markers[i],markersize = 12, mfc='none')
# 		ax2.plot(x, y[i], color[i], marker=markers[i],markersize = 12, mfc='none')
# 	# plt.plot(x, cppg_final, 'b-',marker = 'x',markersize = 10)
#
# 	ax2.legend(legends, loc = legend_pos, frameon=False, prop={'size': 16, 'weight':'normal'})
#
# 	plt.xticks(xx,xticks)
# 	plt.yticks(yticks)
#
# 	# ax2.set_xticklabels(xx,xticks)
# 	ax2.set_yticklabels([])
# 	# ax.set_yticklabels(yticks)
# 	ax2.tick_params(axis='both', which='major', labelsize=26)
# 	ax2.tick_params(axis='both', which='minor', labelsize=26)
# 	ax2.tick_params(axis='y', which='both', length=0)
#
# 	# ax.set_yticklabels(yticks)
# 	ax.tick_params(axis='both', which='major', labelsize=26)
# 	ax.tick_params(axis='both', which='minor', labelsize=26)
#
# 	plt.subplots_adjust(wspace=0)
# 	# plt.label("bhvabkca")
# 	# plt.yticks(y,y)
# 	# axes = plt.gca()
# 	ax.set_xlim(xlim)
# 	ax2.set_xlim(xlim2)
# 	ax.set_ylim(ylim)
# 	ax2.set_ylim(ylim)
#
# 	bx.set_xlim(xlim)
# 	bx2.set_xlim(xlim)
# 	bx.set_ylim(ylim)
# 	bx2.set_ylim(ylim2)
#
#
# 	ax2.set_xlabel(x_label, fontdict = font)
# 	ax2.xaxis.set_label_coords(0.55, 0.07, transform=fig.transFigure)
# 	ax.set_ylabel(y_label, fontdict = font)
#
# 	bx.spines['bottom'].set_visible(False)
# 	bx2.spines['top'].set_visible(False)
# 	bx.xaxis.tick_top()
# 	# ax.tick_params(labeltop=False)  # don't put tick labels at the top
# 	bx2.xaxis.tick_bottom()
#
# 	ax.spines['right'].set_visible(False)
# 	ax2.spines['left'].set_visible(False)
# 	# ax.yaxis.tick_left()
# 	# ax.tick_params(labelright='off')
# 	ax2.yaxis.tick_left()
#
#
# 	d = .009
# 	kwargs = dict(transform=ax.transAxes, color='k', clip_on=False)
# 	ax.plot((1-d,1+d), (-d,+d), **kwargs)
# 	ax.plot((1-d,1+d),(1-d,1+d), **kwargs)
#
# 	kwargs.update(transform=ax2.transAxes)  # switch to the bottom axes
# 	ax2.plot((-d,+d), (1-d,1+d), **kwargs)
# 	ax2.plot((-d,+d), (-d,+d), **kwargs)
#
# 	kwargs = dict(transform=bx.transAxes, color='k', clip_on=False)
# 	bx.plot((-d, +d), (-d, +d), **kwargs)        # top-left diagonal
# 	bx.plot((1 - d, 1 + d), (-d, +d), **kwargs)  # top-right diagonal
#
# 	kwargs.update(transform=bx2.transAxes)  # switch to the bottom axes
# 	bx2.plot((-d, +d), (1 - d, 1 + d), **kwargs)  # bottom-left diagonal
# 	bx2.plot((1 - d, 1 + d), (1 - d, 1 + d), **kwargs)  # bottom-right diagonal
#
# 	# axes.set_title(title)
# 	plt.tight_layout()
# 	plt.savefig(filename, format='eps', dpi=1000)
# 	plt.show()

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	# y = range(2,20,2)
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 12, mfc='none')
	# plt.plot(x, cppg_final, 'b-',marker = 'x',markersize = 10)
	plt.legend(legends, loc = 'upper left', frameon=False, prop={'size': 12, 'weight':'normal'})
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=20)
	plt.tick_params(axis='both', which='minor', labelsize=20)

	# plt.label("bhvabkca")
	# plt.yticks(y,y)
	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)
	# axes.set_title(title)
	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines, strt_line, end_line, cmine_pos, delition_pos):
	cmine = []
	delition = []
	for i in range(strt_line, end_line+1, 1):
		line = lines[i].split(",")

		cmine.append(float(line[cmine_pos])/100.0)
		delition.append(float(line[delition_pos])/100.0)

	return cmine, delition

def plot_ET_Inc():
	lines = open("allmaxor.csv",'r').readlines()
	bms_cmine,bms_prop = get_ET_values(lines, 1, 8, 2, 1)
	cab_cmine,cab_prop = get_ET_values(lines, 1, 8, 4, 3)
	syn_cmine,syn_prop = get_ET_values(lines, 1, 8, 6, 5)

	y_plt = []
	y_plt.append(bms_cmine)
	y_plt.append(bms_prop)
	y_plt.append(cab_cmine)
	y_plt.append(cab_prop)
	y_plt.append(syn_cmine)
	y_plt.append(syn_prop)
	x_plt = np.arange(10,81,10)

	x_dummy_plt = np.arange(10, 81, 10)
	x_ticks = []
	for i in x_dummy_plt:
		# x_ticks.append(str(i/100.0))
		if(i%20==0):
			x_ticks.append(str(i/100))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 13, 3)
	title = "BMS-POS changing delition"
	x_label = "maxOR"
	y_label = "ET ("+r'$ \times 10^2$'+") s"
	legends = ('CPM(B)','CCPM(B)','CPM(C)','CCPM(C)','CPM(S)','CCPM(S)')
	filename = "./all_maxOR.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 81], [0, 13], filename, 2)


if (__name__=='__main__'):
	plot_ET_Inc()
	# plot_CND_Inc()
