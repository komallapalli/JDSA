import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['k','k','k','k','m','y','k','w']
markers = ['o','x','s','^','3','4']

font = {'weight': 'normal',
		'size': 18,}

rc('axes', linewidth=2)

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 12, mfc='none')

	plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 16, 'weight':'normal'},ncol=2)
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=20)
	plt.tick_params(axis='both', which='minor', labelsize=20)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines_cmine, lines_increment, strt_line, end_line, cmine_pos, increment_pos):
	cmine = []
	increment = []
	for i in range(strt_line, end_line+1, 1):
		line1 = lines_cmine[i].split(",")
		line2 = lines_increment[i].split(",")

		cmine.append(float(line1[cmine_pos])/100.0)
		increment.append(float(line2[increment_pos])/100.0)

	return cmine, increment

# def get_CND_values(lines_cmine, lines_increment, strt_line, end_line, cmine_pos, increment_pos):
#     cmine = []
#     increment = []
#     for i in range(strt_line, end_line+1, 1):
#         line1 = lines_cmine[i].split(",")
#         line2 = lines_increment[i].split(",")
#
#         cmine.append(float(line1[cmine_pos])/1000.0)
#         increment.append(float(line2[increment_pos])/1000.0)
#
#     return cmine, increment

def plot_ET_Inc():
	lines_cmine = open("times_final_cabs120k08.csv",'r').readlines()
	lines_increment = open("time_increment_cabs120k08.csv",'r').readlines()
	cmine, increment = get_ET_values(lines_cmine, lines_increment, 1, 10, 8, 9)
	deltime = [0.0546843311447, 0.051700794121199996, 0.0838804133933, 0.216983948381, 4.30722889471, 0.44110521783400003, 5.09279666946, 5.5912691924199995, 6.01624649854, 6.45209815482]
	DBtime = [0.531983438855, 1.01861564588, 1.49718624661, 1.88115649162, 5.55229180529, 2.7027256121699996, 6.62869695054, 7.1755727575799995, 7.65201121146, 8.134880455180001]

	y_plt = []
	y_plt.append(cmine)
	y_plt.append(increment)
	y_plt.append(deltime)
	y_plt.append(DBtime)
	x_plt = np.arange(2,21,2)

	x_dummy_plt = np.arange(2,21, 2)
	x_ticks = []
	for i in x_dummy_plt:
		if(i%4==0):
			x_ticks.append(str(i))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 41, 8)
	title = "cabs changing increment"
	x_label = r'$ \Delta^+ $'+" ("+r'$ \times 10^3$'+")"
	y_label = "ET ("+r'$ \times 10^2$'+") s"
	legends = ('CPM','CCPM','CCPM(d)','CCPM(D)')
	filename = "images/cabs_increment.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 20], [0, 40], filename, 2)

def plot_ET_maxOR():
	lines_cmine = open("times_final_cabs120k08.csv",'r').readlines()
	lines_increment = open("time_increment_cabs120k08.csv",'r').readlines()
	cmine, increment = get_ET_values(lines_cmine, lines_increment, 12, 21, 8, 9)

	y_plt = []
	y_plt.append(cmine)
	y_plt.append(increment)
	x_plt = np.arange(5, 51, 5)

	x_dummy_plt = np.arange(5, 51, 5)
	x_ticks = []
	for i in x_dummy_plt:
		if(i%10==0):
			x_ticks.append(str(i/100.0))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 21, 3)
	title = "cabs changing maxOR"
	x_label = "maxOR"
	y_label = "ET ("+r'$ \times 10^2$'+")s"
	legends = ('CPM','GCPM')
	filename = "images/cabs_maxOR.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [0, 12], filename, 2)



def plot_ET_minRF():
	lines_cmine = open("times_final_cabs120k08.csv",'r').readlines()
	lines_increment = open("time_increment_cabs120k08.csv",'r').readlines()
	cmine, increment = get_ET_values(lines_cmine, lines_increment, 23, 28, 8, 9)

	y_plt = []
	y_plt.append(cmine)
	y_plt.append(increment)
	x_plt = np.arange(35,61,5)

	x_dummy_plt = np.arange(35, 61, 5)
	x_ticks = []
	for i in x_dummy_plt:
		if(i%5==0):
			x_ticks.append(str(i))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 11, 2)
	title = "cabs changing minRF"
	x_label = "minRF ("+r'$ \times 10^{-3}$'+")"
	y_label = "ET ("+r'$ \times 10^2$'+")"
	legends = ('CPM','GCPM')
	filename = "images/cabs_minRF.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [35, 61], [0, 11], filename, 1)


def plot_CND_Inc():
	lines_cmine = open("times_final_cabs120k08.csv",'r').readlines()
	lines_increment = open("time_increment_cabs120k08.csv",'r').readlines()
	cmine, increment = get_CND_values(lines_cmine, lines_increment, 1, 10, 7, 7)

	y_plt = []
	y_plt.append(cmine)
	y_plt.append(increment)
	x_plt = np.arange(2,21,2)

	x_dummy_plt = np.arange(0,21, 2)
	x_ticks = []
	for i in x_dummy_plt:
		if(i%4==0):
			x_ticks.append(str(i))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 31, 5)
	title = "cabs changing increment"
	x_label = r'$ \Delta^+ $'+" ("+r'$ \times 10^4$'+")"
	y_label = "NC ("+r'$ \times 10^3$'+")"
	legends = ('CPM','GCPM')
	filename = "images/cabs_increment_cnd.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 21], [0, 32], filename, 2)

def plot_CND_maxOR():
	lines_cmine = open("times_final_cabs120k08.csv",'r').readlines()
	lines_increment = open("time_increment_cabs120k08.csv",'r').readlines()
	cmine, increment = get_CND_values(lines_cmine, lines_increment, 12, 21, 7, 7)

	y_plt = []
	y_plt.append(cmine)
	y_plt.append(increment)
	x_plt = np.arange(5,51,5)

	x_dummy_plt = np.arange(0, 51, 5)
	x_ticks = []
	for i in x_dummy_plt:
		if(i%10==0):
			x_ticks.append(str(i/100.0))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 11, 2)
	title = "cabs changing maxOR"
	x_label = "maxOR"
	y_label = "NC ("+r'$ \times 10^3$'+")"
	legends = ('CPM','GCPM')
	filename = "images/cabs_maxOR_cnd.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 51], [0, 11], filename, 2)

def plot_CND_minRF():
	lines_cmine = open("times_final_cabs120k08.csv",'r').readlines()
	lines_increment = open("time_increment_cabs120k08.csv",'r').readlines()
	cmine, increment = get_CND_values(lines_cmine, lines_increment, 23, 28, 7, 7)

	y_plt = []
	y_plt.append(cmine)
	y_plt.append(increment)
	x_plt = np.arange(35,61,5)

	x_dummy_plt = np.arange(35, 61, 5)
	x_ticks = []
	for i in x_dummy_plt:
		if(i%5==0):
			x_ticks.append(str(i))
		else:
			x_ticks.append("")
	y_ticks = np.arange(0, 11, 2.5)
	title = "cabs changing minRF"
	x_label = "minRF ("+r'$ \times 10^{-3}$'+")"
	y_label = "NC ("+r'$ \times 10^3$'+")"
	legends = ('CPM','GCPM')
	filename = "images/cabs_minRF_cnd.eps"
	plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [35, 61], [0, 11], filename, 1)


if (__name__=='__main__'):
	plot_ET_Inc()
	# plot_ET_maxOR()
	# plot_ET_minRF()
	# plot_CND_Inc()
	# plot_CND_maxOR()
	# plot_CND_minRF()
