import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['b','g','r','c','m','y','k','w']
markers = ['o','x','1','2','3','4']

font = {'weight': 'normal',
        'size': 24,}

rc('axes', linewidth=2)

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 15, mfc='none')

	plt.legend(legends, loc = legend_pos, frameon=False, prop={'size': 24, 'weight':'normal'})
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=26)
	plt.tick_params(axis='both', which='minor', labelsize=26)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines_cmine, lines_increment, strt_line, end_line, cmine_pos, increment_pos):
    cmine = []
    increment = []
    for i in range(strt_line, end_line+1, 1):
        line1 = lines_cmine[i].split(",")
        line2 = lines_increment[i].split(",")

        cmine.append(float(line1[cmine_pos])/100.0)
        increment.append(float(line2[increment_pos])/100.0)

    return cmine, increment

def get_CND_values(lines_cmine, lines_increment, strt_line, end_line, cmine_pos, increment_pos):
    cmine = []
    increment = []
    for i in range(strt_line, end_line+1, 1):
        line1 = lines_cmine[i].split(",")
        line2 = lines_increment[i].split(",")

        cmine.append(float(line1[cmine_pos])/10000.0)
        increment.append(float(line2[increment_pos])/10000.0)

    return cmine, increment

def plot_CND_Inc():
    lines_cmine = open("times_final_synthetic.csv",'r').readlines()
    lines_increment = open("synNCDelta.csv",'r').readlines()
    cmine, increment = get_CND_values(lines_cmine, lines_increment, 1, 10, 7, 7)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(increment)
    x_plt = np.arange(0.5,5.5,0.5)

    x_dummy_plt = np.arange(0, 5.5, 0.5)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%1==0):
            x_ticks.append(str(int(i)))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 13, 2)
    title = "synthetic changing increment"
    x_label = r'$ \Delta^+ $'+" ("+r'$ \times 10^4$'+")"
    y_label = "NC ("+r'$ \times 10^4$'+")"
    legends = ('CPM','GCPM')
    filename = "./synNCDelta+.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 5], [0, 13], filename, 2)


if (__name__=='__main__'):
    plot_CND_Inc()
