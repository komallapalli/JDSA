import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc,rcParams

color = ['k','k','k','k','m','y','k','w']
markers = ['o','x','s','^','3','4']

font = {'weight': 'normal',
        'size': 18,}

rc('axes', linewidth=2)

def plot_graph(x, y, xx, xticks, yticks, title, x_label, y_label, legends, xlim, ylim, filename, legend_pos):
	for i in range(len(y)):
		plt.plot(x, y[i], color[i], marker=markers[i],markersize = 12, mfc='none')

	plt.legend(legends, loc = 'upper right', frameon=False, prop={'size': 16, 'weight':'normal'})
	plt.xticks(xx,xticks)
	plt.yticks(yticks)
	plt.tick_params(axis='both', which='major', labelsize=20)
	plt.tick_params(axis='both', which='minor', labelsize=20)

	axes = plt.gca()
	axes.set_xlim(xlim)
	axes.set_ylim(ylim)
	axes.set_xlabel(x_label, fontdict = font)
	axes.set_ylabel(y_label, fontdict = font)

	plt.tight_layout()
	plt.savefig(filename, format='eps', dpi=1000)
	plt.show()

def get_ET_values(lines, strt_line, end_line, cmine_pos, delition_pos):
    cmine = []
    delition = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        cmine.append(float(line[cmine_pos])/1000.0)
        delition.append(float(line[delition_pos])/1000.0)

    return cmine, delition

def get_CND_values(lines, strt_line, end_line, cmine_pos, delition_pos):
    cmine = []
    delition = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        cmine.append(float(line[cmine_pos])/1000.0)
        delition.append(float(line[delition_pos])/1000.0)

    return cmine, delition

def get_Psi_values(lines, strt_line, end_line, pos):
    Psi = []
    for i in range(strt_line, end_line+1, 1):
        line = lines[i].split(",")

        Psi.append(float(line[pos]))

    return Psi

def plot_ET():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_ET_values(lines, 1, 10, 6, 5)
    deltime = [1.11208601418, 1.6428160196, 2.7558521099999997, 3.0259095900000004, 4.734852050000001, 6.42123837, 9.010450989999999, 11.64300246, 11.50659062, 11.396774982999998]
    DBtime = [3.84569387082, 5.6810061604, 8.537012090000001, 10.157535900000001, 10.11074477, 9.945281569999999, 10.7966052, 11.425341410000001, 9.82767994, 8.808299567]

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    y_plt.append(deltime)
    y_plt.append(DBtime)
    x_plt = np.arange(1,11,1)

    x_dummy_plt = np.arange(1,11,1)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%2==0):
            x_ticks.append(str(int(i)))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 31, 6)
    title = "synthetic_created changing increment delition"
    x_label = r'$ \Delta^- $'+", "+ r'$ \Delta^+ $' +"("+r'$ \times 10^4$'+")"
    y_label = "ET ("+r'$ \times 10^3$'+") s"
    legends = ('CPM','CCPM','CCPM(d)','CCPM(D)')
    filename = "images/synthetic_created_increment_delition.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 10], [0, 30], filename, 2)


def plot_CND():
    lines = open("synthetic.csv",'r').readlines()
    cmine, delition = get_CND_values(lines, 1, 10, 8, 7)

    y_plt = []
    y_plt.append(cmine)
    y_plt.append(delition)
    x_plt = np.arange(1,11,1)

    x_dummy_plt = np.arange(1,11,1)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%2==0):
            x_ticks.append(str(int(i)))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 121, 15)
    title = "synthetic created changing increment delition"
    x_label = r'$ \Delta^- $'+","+ r'$ \Delta^+ $' +"("+r'$ \times 10^4$'+")"
    y_label = "NC ("+r'$ \times 10^3$'+")"
    legends = ('CPM','GCPM')
    filename = "images/synthetic_created_increment_delition_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 10], [60, 131], filename, 2)

def plot_Psi():
    lines = open("synthetic.csv",'r').readlines()
    Psi = get_Psi_values(lines, 1, 10, 9)
    bms = [1.875, 1.875, 1.521484375, 0.03112792969, 5.01556396484, 18.76556396, 0.01556396484,35.77331543, 0.00778198242, 23.09326172]
    cabs = [13.09326172, 13.09326172, 13.09326172, 13.09326172, 13.09326172, 13.09326172, 13.09326172, 13.09326172, 25.77331543, 13.09326172]

    y_plt = []
    y_plt.append(Psi)
    y_plt.append(bms)
    y_plt.append(cabs)
    x_plt = np.arange(1,11,1)

    x_dummy_plt = np.arange(1,11,1)
    x_ticks = []
    for i in x_dummy_plt:
        if(i%2==0):
            x_ticks.append(str(int(i)))
        else:
            x_ticks.append("")
    y_ticks = np.arange(0, 101, 20)
    title = "synthetic created Psi changing increment delition"
    x_label = r'$ \Delta^- $'+", "+ r'$ \Delta^+ $' +"("+r'$ \times 10^4$'+")"
    y_label = r'$ \Psi $'
    legends = ('Synthetic-Modified','BMS-POS','CABS120k08')
    filename = "images/synthetic_created_Psi_increment_delition_cnd.eps"
    plot_graph(x_plt, y_plt, x_dummy_plt, x_ticks, y_ticks, title, x_label, y_label, legends, [0, 10], [0, 101], filename, 2)


if (__name__=='__main__'):
    # plot_ET()
    # plot_CND()
    plot_Psi()
